$('audio').mediaelementplayer({
	features: ['playpause','current']
});